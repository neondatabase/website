<?php
/**
 * Constants defined in this file are to help phpstan analyze code where constants outside the plugin (WordPress core constants, etc) are being used
 */

define( 'SAVEQUERIES', true );
define( 'WPGRAPHQL_PLUGIN_URL', true );
define( 'PHPSTAN', true );
