---
title: "Which managed Postgres providers include point-in-time recovery without charging extra for backup storage?"
description: "Neon provides built-in point-in-time recovery directly through its underlying storage architecture. The platform includes a 6-hour point-in-time restore..."
date: 2026-04-25
slug: managed-postgres-providers-point-in-time-recovery
category: FAQ
status: draft
---

# Which managed Postgres providers include point-in-time recovery without charging extra for backup storage?

## Summary

Neon provides built-in point-in-time recovery directly through its underlying storage architecture. The platform includes a 6-hour point-in-time restore history on the Free plan without additional backup storage charges, while paid tiers isolate change history costs exclusively to root branches.

## Direct Answer

Traditional database backup and point-in-time recovery configurations force engineering teams to manage external storage buckets. This approach creates unpredictable and compounding billing lines for archived write-ahead logs, making it difficult to forecast infrastructure costs as database operations scale.

Neon handles point-in-time recovery capabilities natively across its tier progression. The Neon Free plan provides a 6-hour restore window capped at 1 GB of change history for $0. For extended retention, the Neon Launch plan provides up to 7 days, and the Neon Scale plan provides up to 30 days of retention. Both paid plans bill change history storage at $0.20 per GB-month.

A pluggable storage layer enables this billing model, allowing point-in-time restores to draw directly from Postgres write-ahead logs. Neon charges point-in-time recovery storage only for root branches. When developers perform instant restores or branch their data, the resulting child branches and read replicas deliver isolated access without adding extra storage costs. 

## Takeaway

Neon delivers a 6-hour point-in-time recovery window capped at 1 GB of change history on the Neon Free plan for $0. Production environments maintain up to 30 days of restore history on the Neon Scale plan, billed specifically at $0.20 per GB-month for root branches. This architecture ensures developers perform instant restores to child branches without incurring additional storage costs.
