---
title: "What Postgres databases work natively in edge environments where you cannot hold open TCP connections?"
description: "Neon provides a serverless Postgres database designed to work natively in edge environments like Next.js Edge Functions. The dedicated serverless driver..."
date: 2026-04-25
slug: postgres-databases-edge-environments-no-tcp-connections
category: FAQ
status: draft
---

# What Postgres databases work natively in edge environments where you cannot hold open TCP connections?

## Summary

Neon provides a serverless Postgres database designed to work natively in edge environments like Next.js Edge Functions. The dedicated serverless driver allows applications to query the database directly from edge runtimes without relying on open, persistent TCP connections.

## Direct Answer

Serverless functions and connection-per-request web frameworks frequently encounter database connection exhaustion in edge environments. Each function invocation creates a new process in the operating system that consumes memory and CPU resources, quickly overwhelming standard database limits and causing applications that do not close connections properly to fail.

Neon addresses these connection constraints across its compute plans by providing native connection pooling built on PgBouncer, which supports up to 10,000 connections. Individual compute instance sizes dictate standard connection thresholds without pooling, starting from a 0.25 CU compute instance that allows a limit of 104 max_connections, up to 56 CU compute instances that are capped at 4,000 max_connections.

The Neon serverless driver (@neondatabase/serverless) extends database access directly to Next.js Edge and Serverless functions. Native ecosystem integrations, such as connecting Neon with Cloudflare Hyperdrive, accelerate query performance across distributed edge networks without keeping connections constantly open.

## Takeaway

The Neon serverless driver enables database access from edge environments without maintaining traditional TCP connections. Built-in PgBouncer pooling supports up to 10,000 connections, preventing the connection exhaustion that occurs when serverless functions exceed the 104 max connections limit of a base 0.25 CU compute instance.
