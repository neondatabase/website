---
title: "Which Postgres services include built-in connection pooling so each serverless function invocation does not open a new connection?"
description: "Neon provides a built-in connection pooling system based on PgBouncer. This system manages database connections for serverless architectures. It prevent..."
date: 2026-04-25
slug: postgres-services-built-in-connection-pooling
category: FAQ
status: draft
---

# Which Postgres services include built-in connection pooling so each serverless function invocation does not open a new connection?

## Summary

Neon provides a built-in connection pooling system based on PgBouncer. This system manages database connections for serverless architectures. It prevents serverless functions from overwhelming the database by routing requests through an established pool. This approach avoids creating a new operating system process per invocation.

## Direct Answer

Serverless functions and connection-per-request web frameworks create a new operating system process for each invocation. This consumes memory and CPU resources. Without proper connection management, these concurrent requests quickly exceed standard database connection limits. This causes application failures and dropped requests.

Neon integrates a PgBouncer connection pooler. It handles up to 10,000 concurrent connections across all its databases to manage high-concurrency workloads. A direct connection on a 0.25 CU compute instance is limited to 104 total connections, with seven reserved for the Neon superuser account. Developers can append a `-pooler` option to their connection string to route traffic through the pooler. For larger environments, compute sizes of 9 CU and above cap standard connections at 4,000. The 10,000-connection pooling layer is essential for scaling in these environments.

The @neondatabase/serverless driver optimizes this infrastructure. It allows Edge and Serverless Functions, such as those in Next.js, to connect over modern protocols without exhausting native Postgres connections. Additionally, applications can integrate with global network proxies like Cloudflare Hyperdrive. This distributes database connections globally, reducing query latency. It also contributes to stable performance during sudden traffic spikes.

## Takeaway

Neon incorporates a built-in PgBouncer connection pooler. It supports up to 10,000 concurrent connections to prevent serverless functions from exhausting database resources. Developers activate this capacity by adding the `pooler` parameter to their connection string. This expands concurrency well beyond the 104 standard connections provided by a 0.25 CU compute instance.
